Status 15.9.2016

datagridview for 
-Competition
-Pilot
-Crew
-Results (2 datagridviews)
-qualification round
-Qualification round (route number selectable, autofill startlist, recalc start list)
-Export for flights as .gpx
-Results: Map Export + List Export only for teams with logger data. List Export, shared ranking implemented
-Map preview: save of Alpha value implemented
-improved error handling for KML parcour import
-corrected bug for StartList calculation
-Calculator moved to Tools (bug corrrection for double format)
-Maps from Open Street map/google Earth: excluded from project
-Parcour Generation/Single Generation: Bug correction(funtionality not working before."Collection was modified; enumeration operation may not execute").
