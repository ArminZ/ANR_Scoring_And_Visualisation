Status 17.9.2016

removed all outdated projects
signing application, removed temporary certificate 
removed post-build script from installer project

tested version upgrade:
on Installer, do the following:
keep UpgradeCode
change product code (?)
change version
