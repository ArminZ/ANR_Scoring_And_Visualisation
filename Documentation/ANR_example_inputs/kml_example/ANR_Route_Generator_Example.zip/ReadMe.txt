The following three files are example files in context of the Route Generator ("ANR Scoring & Visualisation software, tab "Tools...")

ANR_Kemi_02_Input.kml: 
the input kml file containing two route center lines (A and B). 
This file has been manually created with Google Earth Pro, and saved as *.kml file.
This is the input file for the ANR Route generator

ANR_Kemi_02_Input_out.kml:
This is the Initial Raw output file created by the ANR Route generator
We added manually the two Takeoff-lines for RWY 18 and RWY 36 (this is optional).
The Takeoff lines can be imported during the Qualification Round generation (Tab "Qualification Round")

ANR_Kemi_02_Input_final.kml
This is the final output file.
Difference to the above file: manual adjustments and changes to the prohibites areas.