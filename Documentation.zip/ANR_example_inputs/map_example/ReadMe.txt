the following file (ETRS-TM35FIN CRS) was used as a base for re-projection into WGS84.

Kemi_Finland_ETRS-TM35FIN_original.tif: image file with map in ETRS-TM35FIN projection
Kemi_Finland_ETRS-TM35FIN_original.wld: the world-file defining the coordinate data for the above file

The following files (after re-projection into WGS84 CRS) are used as input for the ANR Scoring and Visualisation software:

Kemi_Finland_WGS84_forANR.tif: image file with map in WGS84 projection
Kemi_Finland_WGS84_forANR.wld: the world-file defining the coordinate data for the above file